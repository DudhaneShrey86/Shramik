to do
email verification on registeration
landing page
