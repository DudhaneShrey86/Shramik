<?php $__env->startSection('title', 'Index Page'); ?>
<?php $__env->startSection('csslinks'); ?>
<link rel="stylesheet" href="/css/approve-accounts.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="approve-accounts">
  <div class="row">
    <br>
    <?php if(session()->has('custommsg')): ?>
    <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
    <?php endif; ?>
    <div>
      <div class="col s12">
        <p class="flow-text">Approve Provider Accounts</p>
        <div class="divider">

        </div>
        <br>
      </div>
      <ul class="col s12 collapsible z-depth-0 zeroborder">
      <?php $__empty_1 = true; $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li class="card col s12" data-id="<?php echo e($provider->id); ?>">
        <div class="card-content row smallpadding">
          <div class="col s12 marginallbottom">
            <p class="flow-text"><?php echo e($provider->business_name); ?> <span class="right">#<?php echo e($provider->id); ?></span></p>
            <b class="blue-grey-text"><?php echo e($provider->name); ?></b>
          </div>
          <div class="col s12 l6">
            <p class="paras">Applied On: <span><?php echo e($provider->created_at); ?></span></p>
          </div>
          <div class="col s12 l6 rightonlarge">
            <p>
              <a href="#business_document_<?php echo e($provider->id); ?>" class="links modal-trigger">Business Document Proof</a>
              <a href="#aadhar_card_<?php echo e($provider->id); ?>" class="links modal-trigger">Aadhar Card</a>
            </p>
          </div>
          <div class="modal modal-fixed-footer" id="business_document_<?php echo e($provider->id); ?>">
            <div class="modal-content">
              <embed src="<?php echo e(asset($provider->business_document)); ?>" type="application/pdf" width="100%" height="600px" />
            </div>
            <div class="modal-footer">
              <a class="modal-close btn">Close</a>
            </div>
          </div>
          <div class="modal modal-fixed-footer" id="aadhar_card_<?php echo e($provider->id); ?>">
            <div class="modal-content">
              <embed src="<?php echo e(asset($provider->aadhar_card)); ?>" type="application/pdf" width="100%" height="600px" />
            </div>
            <div class="modal-footer">
              <a class="modal-close btn">Close</a>
            </div>
          </div>
        </div>
        <div class="card-action zeropadding relativediv">
          <p class="rightonlarge absolutebuttons">
            <button type="button" data-actiontype="2" class="actionbuttons btn waves-effect waves-light">Approve</button>
            <button type="button" data-actiontype="0" class="actionbuttons btn waves-effect waves-light red darken-1">Reject</button>
          </p>
          <div class="collapsible-header">
            <button type="button" class="btn blue">Details</button>
          </div>
        </div>
        <div class="collapsible-body">
          <div class="row">
            <div class="col s12">
              <div>
                <p class="flow-text">Provider Details</p>
                <div class="divider">

                </div>
                <br>
              </div>
              <div>
                <div class="col s12 marginallbottom">
                  <h6 class="blue-grey-text"><?php echo e($provider->name); ?></h6>
                </div>
                <div class="col s12 l8 marginallbottom">
                  <p class="blue-grey-text">Business Name: <span><?php echo e($provider->business_name); ?></span></p>
                </div>
                <?php if($provider->email_verified_at != null): ?>
                <div class="col s12 l4 marginallbottom">
                  <p class="rightonlarge"><i class="material-icons green-text">check_circle</i><span>Email Self Verified</span></p>
                </div>
                <?php endif; ?>
              </div>
              <div class="col s12">
                <br>
              </div>
              <div class="col s12 l6">
                <p><b class="blue-grey-text">Email:</b></p>
                <p class="blue-text"><?php echo e($provider->email); ?></p>
              </div>
              <div class="col s12 l6">
                <p><b class="blue-grey-text">Contact:</b></p>
                <p class="blue-text"><?php echo e($provider->contact); ?></p>
              </div>
              <div class="col s12">
                <p><b class="blue-grey-text">Address:</b></p>
                <p class="blue-text">
                  <?php echo nl2br($provider->address); ?>

                </p>
              </div>
              <div class="col s12">
                <br>
                <small class="grey-text text-darken-2">Applied on: <?php echo e($provider->created_at); ?></small>
              </div>
            </div>
          </div>
        </div>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="flow-text">No Providers Accounts to be approved at this moment</p>
      <?php endif; ?>
    </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<script src="/js/approve-accounts.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/admins/approve-accounts.blade.php ENDPATH**/ ?>