<?php $__env->startSection('title', 'Index Page'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="create-users">
  <div class="row">
    <form class="col s12 l6 offset-l3" action="<?php echo e(route('admins.store')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="row">
        <p class="flow-text">Creating A New User</p>
        <p><?php echo e($custommsg ?? ''); ?></p>
        <div class="input-field col s12">
          <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="validate" required>
          <label for="name">Name</label>
          <span class="helper-text red-text text-darken-1" data-error="Required*"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" class="validate" required>
          <label for="email">Email</label>
          <span class="helper-text red-text text-darken-1" data-error="Email address Required*"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>" class="validate" required>
          <label for="password">Password</label>
          <span class="helper-text red-text text-darken-1" data-error="Required*"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input type="number" name="contact" min="0" id="contact" value="<?php echo e(old('contact')); ?>" class="validate" required>
          <label for="contact">Contact Number</label>
          <span class="helper-text red-text text-darken-1" data-error="Valid contact number required*"><?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <select name="designation">
            <option value="" disabled selected>Select A Designation</option>
            <option value="0">Super Admin</option>
            <option value="1">Admin</option>
          </select>
          <span class="helper-text red-text text-darken-1" data-error="Required*"><?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <button class="btn waves-effect waves-light margin-right-button smallmarginright">Create User</button>
          <a href="<?php echo e(route('admins.manage-users')); ?>" class="btn-flat waves-effect white teal-text">Back</a>
        </div>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/admins/create.blade.php ENDPATH**/ ?>