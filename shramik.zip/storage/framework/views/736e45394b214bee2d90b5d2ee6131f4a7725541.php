<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issuperadmin')): ?>
<li><div class="divider"></div></li>
<li><a class="subheader blue-text" href="#"><small>Super Admin Options</small></a></li>
<li id="manage-users"><a class="waves-effect" href=" <?php echo e(route('admins.manage-users')); ?> ">Manage Users</a></li>
<li id="approve-accounts"><a class="waves-effect" href=" <?php echo e(route('admins.approve-accounts')); ?> ">Approve Provider Accounts</a></li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isadmin')): ?>
<li><div class="divider"></div></li>
<li><a class="subheader blue-text" href="#"><small>Admin Options</small></a></li>
<li id="manage-service-types"><a class="waves-effect" href=" <?php echo e(route('admins.manage-service-types')); ?> ">Manage Service Types</a></li>
<li id="manage-users"><a class="waves-effect" href="#">Queries</a></li>
<?php endif; ?>
<?php /**PATH D:\laravel_projects\shramik\resources\views/partials/admins-sidemenu.blade.php ENDPATH**/ ?>