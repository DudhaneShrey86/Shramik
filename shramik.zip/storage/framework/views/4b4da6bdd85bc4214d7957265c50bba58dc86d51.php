<?php $__env->startSection('title', 'Index Page'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="edit-user-<?php echo e($user->id); ?>">
  <div class="row">
    <br>
    <?php if(session()->has('custommsg')): ?>
    <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
    <?php endif; ?>
    <div class="col s12 card">
      <div class="row">
        <div class="col s12">
          <p class="flow-text">User Profile - <?php echo e($user->name); ?> <button type="button" class="btn right" id="editbutton" data-status="start">Edit</button></p>
          <div class="divider">

          </div>
          <br>
        </div>
        <form class="col s12" id="editform" action="<?php echo e(route('admins.edit', $user->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="col s12 l6 input-field">
            <input type="text" name="name" value="<?php echo e($user->name); ?>" disabled class="validate inputs">
            <label for="name" class="active">Name</label>
            <span class="helper-text red-text text-darken-1"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <div class="col s12 l6 input-field">
            <input type="email" name="email" value="<?php echo e($user->email); ?>" disabled class="validate inputs">
            <label for="email" class="active">Email ID</label>
            <span class="helper-text red-text text-darken-1"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <div class="col s12 l6 input-field">
            <input type="number" name="contact" value="<?php echo e($user->contact); ?>" disabled class="validate inputs">
            <label for="contact" class="active">Contact Number</label>
            <span class="helper-text red-text text-darken-1"><?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <div class="col s12 l6 input-field">
            <input type="text" value="<?php if($user->designation == '0'): ?> Super Admin <?php else: ?> Admin <?php endif; ?>" disabled>
            <label class="active">Designation</label>
            <span class="helper-text red-text text-darken-1"></span>
          </div>
          <div class="col s12 l6 input-field">
            <input type="password" name="password" placeholder="New Password" disabled class="validate inputs">
            <label for="password" class="active">Change Password</label>
            <small>Leave blank if no change</small>
            <span class="helper-text red-text text-darken-1"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
          </div>
          <div class="col s12 input-field center">
            <button class="btn waves-effect waves-light inputs marginright" disabled>Update</button>
            <a href="<?php echo e(route('admins.manage-users')); ?>" class="btn-flat waves-effect inputs teal-text">Back</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/edit-profile.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/admins/edit-user.blade.php ENDPATH**/ ?>