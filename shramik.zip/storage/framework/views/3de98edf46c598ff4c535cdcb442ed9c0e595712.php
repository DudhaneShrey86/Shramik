<?php $__env->startSection('title', 'Index Page'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="manage-service-types">
  <div class="row">
    <br>
    <?php if(session()->has('custommsg')): ?>
    <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
    <?php endif; ?>
    <div class="card col s12">
      <div class="row">
        <div class="col s12">
          <p class="flow-text">Manage Service Types <button class="btn blue right modal-trigger" data-target="add-modal"><i class="material-icons left">add</i> Add</button></p>
          <div class="divider">

          </div>
          <table class="striped responsive-table">
            <thead>
              <tr>
                <th>Sr.no</th>
                <th>Name</th>
                <th>Total No of Providers</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php
              $count = $type->providers()->count();
              ?>
              <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($type->name); ?></td>
                <td><?php echo e($count); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="6" class="center flow-text" id="emptymsg">No Service Types Found</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
          <div class="modal" id="add-modal">
            <div class="modal-content">
              <form action="<?php echo e(route('admins.store-service-type')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col s12 l8 offset-l2">
                    <p class="flow-text">Add New Service Type</p>
                    <p>Service Type is the type where a provider belongs to</p>
                    <br>
                  </div>
                  <div class="col s12 l8 offset-l2">
                    <div class="input-field">
                      <input type="text" name="name" id="name" class="validate" required>
                      <label for="name">Enter A Type Name</label>
                      <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                  </div>
                  <div class="col s12 l8 offset-l2">
                    <br>
                    <button class="btn waves-effect waves-light smallmarginright modal-close">Add</button>
                    <button type="button" class="btn white teal-text waves-effect modal-close">Cancel</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/admins/manage-service-types.blade.php ENDPATH**/ ?>