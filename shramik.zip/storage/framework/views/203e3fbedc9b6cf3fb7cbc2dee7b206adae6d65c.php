<?php $__env->startSection('title', "Provider's Login"); ?>
<?php $__env->startSection('sidenavoptions'); ?>
<li class="active"><a class="waves-effect" href="<?php echo e(route('providers.login')); ?>">Login</a></li>
<li class=""><a class="waves-effect" href="<?php echo e(route('providers.register')); ?>">Register</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('topnavoptions'); ?>
<li class="active"><a href="<?php echo e(route('providers.login')); ?>">Login</a></li>
<li class=""><a href="<?php echo e(route('providers.register')); ?>">Register</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <?php if(session()->has('custommsg')): ?>
  <p class="<?php echo e(session()->get('classes')); ?> card col s12 m6 offset-m3 custommsgs"><?php echo e(session()->get('custommsg')); ?></p>
  <?php endif; ?>
  <div class="row" id="login-container">
    <br>
    <div class="card" id="login-form">
      <p class="flow-text">Welcome Back, Provider</p>
      <div class="divider">

      </div>
      <form class="row card-content" action="<?php echo e(route('providers.login.submit')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <p>Logging in as Provider, <a href="<?php echo e(route('consumers.login')); ?>" class="underlined">Change to User</a> </p>
        <br>
        <p class="red-text col s12"><?php echo e($errors->first() ?? ''); ?></p>
        <div class="input-field col s12">
          <input id="email" name="email" type="email" required>
          <label for="email">Email</label>
          <span class="helper-text" data-error="The email must be a valid email address" data-success=""><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="password" name="password" type="password" required>
          <label for="password">Password</label>
          <span class="helper-text" data-error="The password field is required" data-success=""><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <p id="remember-container">
            <label for="remember">
              <input type="checkbox" class="filled-in" name="remember" id="remember" />
              <span>Remember Me</span>
            </label>
            <a href="#" class="underlined right">Forgot Password?</a>
          </p>
        </div>
        <div class="input-field col s12">
          <br>
          <button class="btn waves-effect waves-light blue btn-large col s12">Login</button>
        </div>
        <div class="col s12" id="other-action">
          <br>
          <div class="divider">

          </div>
          <br>
          <p>Don't have an account? <a href="<?php echo e(route('providers.register')); ?>" class="underlined">Sign Up Instead</a></p>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-master-providers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/auth/providers-login.blade.php ENDPATH**/ ?>