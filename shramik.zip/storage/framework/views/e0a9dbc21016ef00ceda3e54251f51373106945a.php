to do
manage users admins
<?php /**PATH D:\laravel_projects\shramik\resources\views/home.blade.php ENDPATH**/ ?>