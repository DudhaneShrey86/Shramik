<?php $__env->startSection('title', "Consumers's Login"); ?>
<?php $__env->startSection('sidenavoptions'); ?>
<li class=""><a class="waves-effect" href="<?php echo e(route('consumers.login')); ?>">Login</a></li>
<li class="active"><a class="waves-effect" href="<?php echo e(route('consumers.register')); ?>">Register</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('topnavoptions'); ?>
<li class=""><a href="<?php echo e(route('consumers.login')); ?>">Login</a></li>
<li class="active"><a href="<?php echo e(route('consumers.register')); ?>">Register</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <input type="hidden" id="localities" value="<?php echo e($localities); ?>">
  <div class="row">
    <br>
    <div class="card col s12 l6 center offset-l3">
      <h5 class="marginbottom marginbigtop">Welcome to Shramik</h5>
      <h6 class="blue-grey-text">A platform to bring neighbouring services online</h6>
      <br>
      <div class="divider">

      </div>
      <form class="row card-content" action="<?php echo e(route('consumers.register.submit')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p>Registering as a User, <a href="<?php echo e(route('providers.register')); ?>" class="underlined">Change to Provider</a></p>
        <br>
        <p class="red-text col s12"><?php echo e($errors->first() ?? ''); ?></p>
        <div class="input-field col s12">
          <input id="name" name="name" type="text" class="validate">
          <label for="name">Enter Your Name</label>
          <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="contact" name="contact" type="number" class="validate" >
          <label for="contact">Enter Your Contact Number</label>
          <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <textarea name="address" id="address" class="materialize-textarea validate" ></textarea>
          <label for="address">Enter your address</label>
          <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="locality" name="locality" type="text" class="validate">
          <label for="locality">Enter Your Locality</label>
          <small>This will be used to find nearby services. It can be changed later</small>
          <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['locality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="email" name="email" type="email" class="validate" >
          <label for="email">Enter Your Email ID</label>
          <small>A mail will be sent to your id to confirm your registration</small>
          <span class="helper-text" data-error="Valid email address *" data-success=""><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="password" name="password" type="password" class="validate" >
          <label for="password">Enter A Password</label>
          <small>Minimum 8 characters</small>
          <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="password_confirmation" name="password_confirmation" type="password" class="validate" >
          <label for="password_confirmation">Retype your Password</label>
          <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12" id="center-input-field">
          <button class="btn waves-effect waves-light blue btn-large">Register</button>
        </div>
        <div class="col s12" id="other-action">
          <br>
          <div class="divider">

          </div>
          <br>
          <p>Already have an account? <a href="<?php echo e(route('consumers.login')); ?>" class="underlined">Sign In</a></p>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/providers-register.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-master-providers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/auth/consumers-register.blade.php ENDPATH**/ ?>