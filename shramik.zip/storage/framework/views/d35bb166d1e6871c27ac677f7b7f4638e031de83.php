
<?php $__env->startSection('title', 'Provider Dashboard'); ?>
<?php $__env->startSection('csslinks'); ?>
<link rel="stylesheet" href="/css/providers-dashboard.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="dashboard">
  <?php if(session()->has('custommsg')): ?>
  <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
  <?php endif; ?>
  <div id="flex-container">
    <div id="big-div">
      <?php if($user->is_approved == 1 || $user->is_approved == 0): ?>
      <div class="card">
        <div class="card-content flex-card">
          <div class="text-div">
            <p class="card-title marginbottom">Update Business Proof Documents</p>
            <p>Upload a business proof and your aadhar card to get a verified account.<br> Only verified accounts are shown in our search lists</p>
          </div>
          <div class="button-div">
            <?php if($user->is_approved == 1): ?>
            <button type="button" class="btn fullbuttons disabled">Waiting for approval</button>
            <?php else: ?>
            <a href="" class="btn fullbuttons">Go There</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php if($user->profile_pic == '/images/profile-user.png'): ?>
      <div class="card">
        <div class="card-content flex-card">
          <div class="text-div">
            <p class="card-title marginbottom">Update Profile Picture</p>
            <p>Keeping a profile picture creates a sense of authenticity in the users</p>
          </div>
          <div class="button-div">
            <a href="<?php echo e(route('providers.profile', Auth::user()->id)); ?>" class="btn fullbuttons">Update Pic</a>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php if($user->latitude == null): ?>
      <div class="card">
        <div class="card-content flex-card">
          <div class="text-div">
            <p class="card-title marginbottom">Update My Business Location</p>
            <p>Provider locations are used in consumer's search results</p>
          </div>
          <div class="button-div">
            <a href="<?php echo e(route('providers.profile', Auth::user()->id)); ?>" class="btn fullbuttons">Update Location</a>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <div class="card">
        <div class="card-content">
          <p class="card-title marginbottom">Recent Updates</p>
          <div class="divider">

          </div>
          <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
          $data = $notification->data;
          $type = $data['type'];
          $class = "";
          if($notification->read_at == null){
            $class = "newnotification";
          }
          $task = Auth::guard('provider')->user()->tasks()->find($data['task_id']);
          $consumer = $task->consumer()->find($data['consumer_id']);
          ?>
          <?php
          switch($type){
            case 'Accepted Application':
            ?>
            <div class="customcard <?php echo e($class); ?>">
              <h6 class="valign-wrapper"><span class="">Account Verified!</span>&nbsp;<i class="material-icons green-text">check</i> </h6>
              <div class="content">
                <p>Congratulations! Your account has been verified.</p>
                <p>Verified accounts often rank higher in search lists - <a href="#" class="underlined">know more here</a> </p>
              </div>
            </div>

            <?php
              break;
            case 'Rejected Application':
            ?>
            <div class="customcard">
              <h6>Account Rejected</h6>
              <div class="content">
                <p>Your account was rejected recently. This generally happens if the uploaded documents were invalid or improper</p>
                <p>You will not be shown in our search lists as long as your account remains rejected - <a href="#" class="underlined">know more here</a> </p>
                <p>Please re-submit valid documents</p>
                <a href="#" class="btn btn-small blue fullbuttons2 margintop">Go There</a>
              </div>
            </div>


            <?php
              break;
            case 'Cancelled Provider':
            ?>
            <div class="customcard">
              <h6>Task Cancelled</h6>
              <div class="content">
                <p>The task "<a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->name); ?></a>" by <b><?php echo e($consumer->name); ?></b> was cancelled.</p>
                <p>Keep trying!</p>
                <a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            case 'Hired Provider':
            ?>
            <div class="customcard">
              <h6>Hired for a task</h6>
              <div class="content">
                <p>You were hired by <b><?php echo e($consumer->name); ?></b> for the task "<a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->title); ?></a>"</p>
                <a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            case 'Reviewed Provider':
            ?>
            <div class="customcard">
              <h6>Review Gained</h6>
              <div class="content">
                <p><b><?php echo e($Tconsumer->name); ?></b> provided their review on your performance for the task "<a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->name); ?></a>"</p>
                <div class="rating-div">
                  <p><b>Rating Given: <span>4.5/5</span></b></p>
                  <span class="rating-span">
                    <?php
                    for($i = 0;$i<5;$i++){
                      $value = "star";
                      ?>
                      <i class="material-icons"><?php echo e($value); ?></i>
                      <?php
                    }
                    ?>
                  </span>
                </div>
                <a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            case 'Task Completed Provider':
            ?>
            <div class="customcard">
              <h6>Task Completed</h6>
              <div class="content">
                <p>Congratulations! You succesfully completed the task "<a href="#" class="underlined">Some Task</a>" for <a href="#" class="underlined">Some Person</a></p>
                <p>Keep up the good work!</p>
                <a href="#" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            default:
            ?>

            <?php
              break;
          }
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="customcard center">
            <div id="empty-notification-div">
              <img src="<?php echo e(asset('/images/empty.png')); ?>" alt="">
            </div>
            <h5>No Updates for now</h5>
            <p><i>Start doing stuff - complete your profile, read the guidelines or provide services!</i></p>
          </div>
          <?php endif; ?>
          <?php
          $notifications->markAsRead();
          ?>
        </div>
      </div>
    </div>
    <div id="small-div">
      <div class="card">
        <div class="card-content">
          <?php
          $tasks = "-";
          if($user->reviews_gained != 0){
            $tasks = $user->reviews_gained;
          }
          $avg_rating = "-";
          $reviews = $user->reviews()->get();
          $count = count($reviews);
          if($count != 0){
            $v = 0;
            foreach($reviews as $review){
              $v += $review->rating;
            }
            $avg_rating = $v / $count;
            $avg_rating = number_format((float)$avg_rating, 2, '.', '');
            $avg_rating = $avg_rating."/5";
          }
          ?>
          <h5>Welcome <?php echo e(explode(" ", Auth::user()->name)[0]); ?></h5>
          <div class="divider">

          </div>
          <div class="customrow">
            <p>Your Provider Rating</p>
            <b><?php echo e($avg_rating); ?></b>
          </div>
          <div class="customrow">
            <p>Tasks completed</p>
            <b><?php echo e($tasks); ?></b>
          </div>
          <div class="customrow">
            <p>Update Your Profile</p>
            <a href="<?php echo e(route('providers.profile', Auth::user()->id)); ?>" class="btn btn-small fullbuttons margintop">Go To Profile</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.providers-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/providers/index.blade.php ENDPATH**/ ?>