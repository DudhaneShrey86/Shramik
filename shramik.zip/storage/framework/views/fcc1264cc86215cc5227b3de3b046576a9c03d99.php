<?php $__env->startSection('title', "Admin's Login"); ?>
<?php $__env->startSection('sidenavoptions'); ?>
<li class="active"><a class="waves-effect" href="#">Login</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('topnavoptions'); ?>
<li class="active"><a href="#">Login</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row">
    <br>
    <div class="card col s12 m6 offset-m3">
      <form class="row card-content" action="<?php echo e(route('admins.login.submit')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <p class="flow-text">Admin's Login</p>
        <br>
        <p class="red-text col s12"><?php echo e($errors->first() ?? ''); ?></p>
        <div class="input-field col s12">
          <input id="email" name="email" type="email" class="validate" required>
          <label for="email">Email</label>
          <span class="helper-text" data-error="The email must be a valid email address" data-success=""><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12">
          <input id="password" name="password" type="password" class="validate" required>
          <label for="password">Password</label>
          <span class="helper-text" data-error="The password field is required" data-success=""><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        </div>
        <div class="input-field col s12 l6">
          <p>
            <label for="remember">
              <input type="checkbox" class="filled-in" name="remember" id="remember" />
              <span>Remember Me</span>
            </label>
          </p>
        </div>
        <div class="input-field col s12">
          <button class="btn waves-effect waves-light">Login</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-master-admins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/auth/admins-login.blade.php ENDPATH**/ ?>