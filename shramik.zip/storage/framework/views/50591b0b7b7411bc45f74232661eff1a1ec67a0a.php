<?php $__env->startSection('title', 'Consumer Dashboard'); ?>
<?php $__env->startSection('csslinks'); ?>
<link rel="stylesheet" href="/css/providers-dashboard.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="dashboard">
  <?php if(session()->has('custommsg')): ?>
  <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
  <?php endif; ?>
  <div id="flex-container">
    <div id="big-div">
      <div class="card">
        <div class="card-content flex-card">
          <div class="text-div">
            <p class="card-title marginbottom">Hire A Service</p>
            <p>Find the best providers in your neighbourhood</p>
          </div>
          <div class="button-div">
            <a href="<?php echo e(route('consumers.search')); ?>" class="btn blue fullbuttons">Search</a>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-content">
          <p class="card-title marginbottom">Recent Updates</p>
          <div class="divider">

          </div>
          <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
          $data = $notification->data;
          $type = $data['type'];
          $task = Auth::guard('consumer')->user()->tasks()->find($data['task_id']);
          $provider = $task->provider()->find($data['provider_id']);
          ?>
          <?php
          switch($type){
            case 'Cancelled Provider':
            ?>
            <div class="customcard">
              <h6>Task Cancelled</h6>
              <div class="content">
                <p>You cancelled the task - "<a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->title); ?></a>" for <b><?php echo e($provider->name); ?></b> </p>
                <p>No worries! You will find the best provider for your task.</p>
                <a href="#" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            case 'Hired Provider':
            ?>
            <div class="customcard">
              <h6>Hired a Provider</h6>
              <div class="content">
                <p>You hired <b><?php echo e($provider->name); ?></b> for the task "<a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->title); ?></a>"</p>
                <a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            case 'Reviewed Provider':
            ?>
            <div class="customcard">
              <h6>Review Given</h6>
              <div class="content">
                <p>You submitted a review for <b><?php echo e($provider->name); ?></b> for their performance on the task "<a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->title); ?></a>"</p>
                <div class="rating-div">
                  <p><b>Rating Given: <span>4.5/5</span></b></p>
                  <span class="rating-span">
                    <?php
                    for($i = 0;$i<5;$i++){
                      $value = "star";
                      ?>
                      <i class="material-icons"><?php echo e($value); ?></i>
                      <?php
                    }
                    ?>
                  </span>
                </div>
                <a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            case 'Task Completed Provider':
            ?>
            <div class="customcard">
              <h6>Task Completed</h6>
              <div class="content">
                <p>The task "<a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->title); ?></a>" by <b><?php echo e($provider->name); ?></b> was completed succesfully! </p>
                <p>Thank You for using our platform!</p>
                <a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" class="btn btn-small blue fullbuttons2 margintop">Go To Task</a>
              </div>
            </div>


            <?php
              break;
            default:
            ?>

            <?php
              break;
          }
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="customcard center">
            <div id="empty-notification-div">
              <img src="<?php echo e(asset('/images/empty.png')); ?>" alt="">
            </div>
            <h5>No Updates for now</h5>
            <p><i>Start hiring services online!</i></p>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div id="small-div">
      <div class="card">
        <div class="card-content">
          <?php
          $reviews = "-";
          if($user->reviews_given != 0){
            $reviews = $user->reviews_given;
          }
          $tasks = $user->tasks()->get();
          $count = count($tasks);
          $task_text = "-";
          if($count != 0){
            $task_text = $count;
          }
          ?>
          <h5>Welcome <?php echo e(explode(" ", Auth::user()->name)[0]); ?></h5>
          <div class="divider">

          </div>
          <div class="customrow">
            <p>Tasks on Shramik</p>
            <b><?php echo e($task_text); ?></b>
          </div>
          <div class="customrow">
            <p>Reviews Given</p>
            <b><?php echo e($reviews); ?></b>
          </div>
          <div class="customrow">
            <p>Update Your Profile</p>
            <a href="<?php echo e(route('consumers.profile', Auth::user()->id)); ?>" class="btn btn-small fullbuttons margintop">Go To Profile</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.consumers-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/consumers/index.blade.php ENDPATH**/ ?>