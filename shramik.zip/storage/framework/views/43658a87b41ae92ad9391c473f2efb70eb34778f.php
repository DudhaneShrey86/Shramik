<?php
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
  }
?>

<?php $__env->startSection('title', 'Consumer Profile'); ?>
<?php $__env->startSection('csslinks'); ?>
<link rel="stylesheet" href="/css/providers-profile.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="dashboard">
  <?php if(session()->has('custommsg')): ?>
  <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
  <?php endif; ?>
  <div id="parentdiv">
    <div id="imagediv">
      <img src="<?php echo e(asset($consumer->profile_pic)); ?>" alt="">
      <?php if($canedit): ?>
      <form id="upload_pic_form" action="<?php echo e(route('consumers.profile.submit', $consumer->id)); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <label for="profile_pic" class="btn waves-effect blue"><i class="material-icons left">edit</i><span>Change Pic</span></label>
        <input type="file" name="profile_pic" id="profile_pic" value=""><br>
        <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['profile_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
      </form>
      <?php endif; ?>
    </div>
    <div id="contentdiv" class="card">
      <div class="card-content">
        <div id="flex-container">
          <div id="big-div">
            <h6>Details</h6>
            <div class="divider">

            </div>
            <div class="">
              <div class="row">
                <div class="smallmarginbottom">
                  <p class="flow-text"><?php echo e($consumer->name); ?></p>
                </div>
                <div class="smallmarginbottom">
                  <p>Joined On</p>
                  <?php
                  $date = $consumer->created_at;
                  $date = date_create($date);
                  $date = date_format($date, "jS F Y");
                  ?>
                  <p class="blue-grey-text"><b><?php echo e($date); ?></b></p>
                </div>
                <div class="col s12">
                  <p>Address:</p>
                  <p class="blue-grey-text small-text">
                    <?php echo nl2br($consumer->address); ?>

                  </p>
                </div>
                <div>
                  <div class="col s12 l6">
                    <p>Email ID</p>
                    <p class="blue-text"><b><?php echo e($consumer->email); ?></b></p>
                  </div>
                  <div class="col s12 l6">
                    <p>Contact</p>
                    <p class="blue-text"><b><?php echo e($consumer->contact); ?></b></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div id="blank-div">

          </div>
          <div id="small-div">
            <h6>Stats</h6>
            <div class="divider">

            </div>
            <div>
              <div class="row">
                <div class="col s12">
                  <p>Reviews Given</p>
                  <?php
                  $count = $consumer->reviews_given;
                  if($count == 0){
                    $count = "-";
                  }
                  ?>
                  <p class="blue-grey-text"><b><?php echo e($count); ?></b></p>
                </div>
                <div class="col s12">
                  <p>Tasks on Shramik</p>
                  <?php
                  $count = count($tasks);
                  if($count == 0){
                    $count = "-";
                  }
                  ?>
                  <p class="blue-grey-text"><b><?php echo e($count); ?></b></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php if($canedit): ?>
    <div class="card" id="location">
      <div class="card-content">
        <h5>Set Your Location</h5>
        <div class="divider">

        </div>
        <div>
          <p>Your location will be used while searching for providers</p>
          <p class="blue-grey-text text-darken-1"><small>This location is only visible to you</small></p>
          <div id="locationmap" class="lightborder">
            <p class="flow-text">Space for maps</p>
          </div>
          <div>
            <p>Use the button below to set your location</p>
            <p class="marginbottom"><small id="erroroutput">Make sure to allow location access</small></p>
            <form id="form" action="<?php echo e(route('consumers.setlocation', $consumer->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="latitude" id="latitude" value="">
              <input type="hidden" name="longitude" id="longitude" value="">
              <?php
              $str = '';
              if($consumer->latitude == null){
                $str = 'Set Location';
              }
              else{
                $str = 'Update Location';
              }
              ?>
              <p><button type="button" onclick="setLocation()" id="setlocation" class="btn blue"><?php echo e($str); ?></button></p>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php else: ?>

    <?php endif; ?>
    <div class="card" id="reviews">
      <div class="card-content">
        <h5>Reviews Given <small class="right"><?php echo e($consumer->reviews_given); ?> reviews</small></h5>
        <div class="divider">

        </div>
        <div>
          <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
          $review = $task->review()->first();
          $provider = $task->provider()->first();
          ?>
          <div class="customcard">
            <div class="row marginbottom">
              <div class="col s12 l6">
                <p><a href="<?php echo e(route('consumers.task.show', $task->id)); ?>" target="_blank" class="underlined"><?php echo e($task->title); ?></a></p>
              </div>
              <?php if($review != null): ?>
              <div class="col s12 l6 rightonlarge">
                <span>
                  <?php
                  $rating = $review->rating;
                  $str = "";
                  for($i = 1; $i <= 5; $i++){
                    if($i <= $rating){
                      ?>
                      <i class="material-icons amber-text">star</i>
                      <?php
                    }
                    else if(($i - $rating) <= 0.5){
                      ?>
                      <i class="material-icons amber-text">star_half</i>
                      <?php
                    }
                    else{
                      ?>
                      <i class="material-icons amber-text">star_border</i>
                      <?php
                    }
                  }
                  ?>
                </span>
              </div>
              <div class="col s12">
                <p class="small-text">
                  <i>"<?php echo e($review->text); ?>"</i>
                </p>
              </div>
              <?php endif; ?>
              <div class="col s12">
                <p>- <a href="#" class="underlined"><?php echo e($provider->name); ?></a> </p>
              </div>
            </div>
            <p><small><?php echo e(time_elapsed_string($task->created_at)); ?></small></p>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="customcard">
            <p class="flow-text">No Reviews Found!</p>
            <p class="grey-text"><i>Start using the platform to get some work done!</i></p>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<script src="/js/profile.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.consumers-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/consumers/profile.blade.php ENDPATH**/ ?>