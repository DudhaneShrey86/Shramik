<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="/css/index.css">
    <link rel="stylesheet" href="/css/admins.css">
    <?php echo $__env->yieldContent('csslinks'); ?>
  </head>
  <body>
    <header>
      <ul class="sidenav sidenav-fixed" id="side-menu">
        <li>
          <div class="user-view">
            <a href="#email"><span class="username"><?php echo e(Auth::user()->name ?? ''); ?></span></a>
            <a href="#email"><span class="email"><?php echo e(Auth::user()->email ?? ''); ?></span></a>
          </div>
        </li>
        <?php echo $__env->make('partials.admins-sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <li><div class="divider"></div></li>
        <?php if(Auth::user()): ?>
        <li id="edit-user-<?php echo e(Auth::user()->id); ?>"><a class="waves-effect" href="<?php echo e(route('admins.edit', Auth::user()->id)); ?>">User Profile</a></li>
        <li><a class="waves-effect modal-trigger" href="#logoutmodal">Logout</a></li>
        <?php else: ?>
        <li><a class="waves-effect" href="/trustusers">Login</a></li>
        <?php endif; ?>
      </ul>
      <div class="navbar">
        <ul class="dropdown-content" id="userdropdown">
          <li><a href="#logoutmodal" class="modal-trigger">Logout</a></li>
        </ul>
        <nav class="blue darken-2">
          <div class="container nav-wrapper">
            <a href="<?php echo e(route('home')); ?>" class="brand-logo">Shramik</a>
            <a href="#!" data-target="side-menu" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            <ul class="right hide-on-med-and-down">
              <?php if(Auth::user()): ?>
              <li><a style="background: transparent !important">Hello <?php echo e(Auth::user()->name); ?></a></li>
              <li><a class="dropdown-trigger" href="#!" data-target="userdropdown"><i class="material-icons">account_circle</i></a></li>
              <?php else: ?>
              <li><a href="/admins">Login</a></li>
              <?php endif; ?>
            </ul>
          </div>
        </nav>
      </div>
      <div class="modal" id="logoutmodal">
        <div class="modal-content center">
          <i class="large material-icons white amber-text text-lighten-1 circle">info</i>
          <p class="flow-text">Are you sure you want to logout?</p>
        </div>
        <div class="modal-footer">
          <button class="btn modal-close waves-effect waves-light white teal-text">Cancel</button>
          <a href="<?php echo e(route('admins.logout')); ?>" class="btn modal-close waves-effect waves-light">Logout</a>
        </div>
      </div>
    </header>
    <main>
      <div class="container">

      </div>
      <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer></footer>
    <script src="/js/jquery.js" charset="utf-8"></script>
    <script src="/js/materialize.min.js" charset="utf-8"></script>
    <script src="/js/index.js" charset="utf-8"></script>
    <script type="text/javascript">
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>
<?php /**PATH D:\laravel_projects\shramik\resources\views/layouts/admins-master.blade.php ENDPATH**/ ?>