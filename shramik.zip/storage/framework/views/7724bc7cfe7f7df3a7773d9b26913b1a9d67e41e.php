<?php
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
  }
?>

<?php $__env->startSection('title', 'Provider Profile'); ?>
<?php $__env->startSection('csslinks'); ?>
<link rel="stylesheet" href="/css/providers-profile.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="dashboard">
  <?php if(session()->has('custommsg')): ?>
  <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
  <?php endif; ?>
  <div id="parentdiv">
    <div id="imagediv">
      <img src="<?php echo e(asset($provider->profile_pic)); ?>" alt="">
      <?php if($canedit): ?>
      <form id="upload_pic_form" action="<?php echo e(route('providers.profile.submit', $provider->id)); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <label for="profile_pic" class="btn waves-effect blue"><i class="material-icons left">edit</i><span>Change Pic</span></label>
        <input type="file" name="profile_pic" id="profile_pic" value=""><br>
        <span class="helper-text" data-error="Required*" data-success=""><?php $__errorArgs = ['profile_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
      </form>
      <?php endif; ?>
    </div>
    <div id="contentdiv" class="card">
      <div class="card-content">
        <div id="flex-container">
          <div id="big-div">
            <h6>Details</h6>
            <div class="divider">

            </div>
            <div class="">
              <div class="row">
                <div class="smallmarginbottom">
                  <p class="flow-text"><?php echo e($provider->name); ?>

                    <?php if($canedit): ?>
                    <button type="button" class="btn right btn-small active" id="editbutton"><i class="material-icons">edit</i></button>
                    <?php endif; ?>
                  </p>
                </div>
                <div class="smallmarginbottom">
                  <p class="blue-grey-text"><i><?php echo e($provider->business_name); ?></i></p>
                </div>
                <div class="smallmarginbottom">
                  <p class="blue-grey-text"><b><?php echo e($provider->type()->first()->name); ?></b></p>
                </div>
                <div>
                  <?php
                  $avg_rating = 0;
                  $reviews = $provider->reviews()->get();
                  $count = count($reviews);
                  if($count != 0){
                    $v = 0;
                    foreach($reviews as $review){
                      $v += $review->rating;
                    }
                    $avg_rating = $v / $count;
                  }
                  ?>
                  <div class="col s12 l6">
                    <p>Average Rating:</p>
                    <p>
                      <span>
                        <?php
                        for($i = 1; $i <= 5; $i++){
                          if($i <= $avg_rating){
                            ?>
                            <i class="material-icons amber-text">star</i>
                            <?php
                          }
                          else if(($i - $avg_rating) <= 0.5){
                            ?>
                            <i class="material-icons amber-text">star_half</i>
                            <?php
                          }
                          else{
                            ?>
                            <i class="material-icons amber-text">star_border</i>
                            <?php
                          }
                        }
                        ?>
                      </span>
                    </p>
                  </div>
                  <div class="col s12 l6">
                    <p>Joined On</p>
                    <?php
                    $date = $provider->created_at;
                    $date = date_create($date);
                    $date = date_format($date, "jS F Y");
                    ?>
                    <p class="blue-grey-text"><b><?php echo e($date); ?></b></p>
                  </div>
                </div>
                <div class="col s12">
                  <p>Address:</p>
                  <p class="blue-grey-text small-text">
                    <?php echo nl2br($provider->address); ?>

                  </p>
                </div>
                <div>
                  <div class="col s12 l6">
                    <p>Email ID</p>
                    <p class="blue-text"><b><?php echo e($provider->email); ?></b></p>
                  </div>
                  <div class="col s12 l6">
                    <p>Contact</p>
                    <p class="blue-text"><b><?php echo e($provider->contact); ?></b></p>
                  </div>
                </div>
                <div class="col s12">
                  <p>Summary</p>
                  <form action="<?php echo e(route('providers.profile.submit', $provider->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <textarea class="custominputs small-text" readonly id="summary" name="summary" placeholder="Enter a short summary about your business"><?php echo nl2br($provider->summary); ?></textarea>
                    <div id="savediv">
                      <button type="submit" class="smallmarginright btn" id="savebutton">Save Changes</button>
                      <button type="reset" class="btn white teal-text" id="cancelbutton">Cancel</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div id="blank-div">

          </div>
          <div id="small-div">
            <h6>Stats</h6>
            <div class="divider">

            </div>
            <div>
              <div class="row">
                <div class="col s12">
                  <p class="vertical-align">
                    <span>Email Verified</span>
                    <?php if($provider->email_verified_at != null): ?>
                    <i class="material-icons green-text right" title="verified">check_circle</i>
                    <?php else: ?>
                    <i class="material-icons red-text right" title="not verified">cancel</i>
                    <?php endif; ?>
                  </p>
                </div>
                <div class="col s12">
                  <p class="vertical-align">
                    <span>Account Verified</span>
                    <?php
                    $title = "";
                    $text = "";
                    $class = "";
                    if($provider->is_approved == 2){
                      $title = "verified";
                      $text = "check_circle";
                      $class = "green-text";
                    }
                    else if($provider->is_approved == 1){
                      $title = "pending approval";
                      $text = "update";
                      $class = "amber-text";
                    }
                    else{
                      $title = "rejected";
                      $text = "cancel";
                      $class = "red-text";
                    }
                    ?>
                    <i class="material-icons right <?php echo e($class); ?>" title="<?php echo e($title); ?>"><?php echo e($text); ?></i>
                  </p>
                </div>
                <div class="col s12">
                  <p>Reviews Gained</p>
                  <?php
                  $count = $provider->reviews_gained;
                  if($count == 0){
                    $count = "-";
                  }
                  ?>
                  <p class="blue-grey-text"><b><?php echo e($count); ?></b></p>
                </div>
                <div class="col s12">
                  <p>Jobs Done</p>
                  <?php
                  $count = count($tasks);
                  if($count == 0){
                    $count = "-";
                  }
                  ?>
                  <p class="blue-grey-text"><b><?php echo e($count); ?></b></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php if($canedit): ?>
    <div class="card" id="location">
      <div class="card-content">
        <h5>Set Business Location</h5>
        <div class="divider">

        </div>
        <div>
          <p>Your location will help us to rank you in respective consumer's search results</p>
          <p class="amber-text text-darken-2"><small>This location is visible to everyone</small></p>
          <div id="locationmap" class="lightborder">
            <p class="flow-text">Space for maps</p>
          </div>
          <div>
            <p>Use the button below to set your location</p>
            <p class="marginbottom"><small id="erroroutput">Make sure to allow location access</small></p>
            <form id="form" action="<?php echo e(route('providers.setlocation', $provider->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="latitude" id="latitude" value="">
              <input type="hidden" name="longitude" id="longitude" value="">
              <?php
              $str = '';
              if($provider->latitude == null){
                $str = 'Set Location';
              }
              else{
                $str = 'Update Location';
              }
              ?>
              <p><button type="button" onclick="setLocation()" id="setlocation" class="btn blue"><?php echo e($str); ?></button></p>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div class="card" id="location">
      <div class="card-content">
        <h5>Business Location</h5>
        <div class="divider">

        </div>
        <div>
          <div id="locationmap" class="lightborder">
            <p class="flow-text">Space for maps</p>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <div class="card" id="reviews">
      <div class="card-content">
        <h5>Reviews <small class="right"><?php echo e($provider->reviews_gained); ?> reviews</small></h5>
        <div class="divider">

        </div>
        <div>
          <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
          $review = $task->review()->first();
          $consumer = $task->consumer()->first();
          ?>
          <div class="customcard">
            <div class="row marginbottom">
              <div class="col s12 l6">
                <p><a href="<?php echo e(route('providers.task.show', $task->id)); ?>" target="_blank" class="underlined"><?php echo e($task->title); ?></a></p>
              </div>
              <div class="col s12 l6 rightonlarge">
                <span>
                  <?php
                  $rating = $review->rating;
                  $str = "";
                  for($i = 1; $i <= 5; $i++){
                    if($i <= $rating){
                      ?>
                      <i class="material-icons amber-text">star</i>
                      <?php
                    }
                    else if(($i - $rating) <= 0.5){
                      ?>
                      <i class="material-icons amber-text">star_half</i>
                      <?php
                    }
                    else{
                      ?>
                      <i class="material-icons amber-text">star_border</i>
                      <?php
                    }
                  }
                  ?>
                </span>
              </div>
              <div class="col s12">
                <p class="small-text">
                  <i>"<?php echo e($review->text); ?>"</i>
                </p>
              </div>
              <div class="col s12">
                <p>- <a href="#" class="underlined"><?php echo e($consumer->name); ?></a> </p>
              </div>
            </div>
            <p><small><?php echo e(time_elapsed_string($task->created_at)); ?></small></p>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="customcard">
            <p class="flow-text">No Reviews Found!</p>
            <p class="grey-text"><i>Keep your profile updated to get more opportunities</i></p>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<script src="/js/profile.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.providers-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/providers/profile.blade.php ENDPATH**/ ?>