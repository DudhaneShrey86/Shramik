<?php $__env->startSection('title', 'Index Page'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="manage-users">
  <div class="row">
    <br>
    <?php if(session()->has('custommsg')): ?>
    <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
    <?php endif; ?>
    <div class="card col s12">
      <div class="row">
        <div class="col s12">
          <p class="flow-text">Manage Users <a href="<?php echo e(route('admins.create')); ?>" class="btn blue right"><i class="material-icons left">add</i> Add User</a></p>
          <div class="divider">

          </div>
          <table class="striped responsive-table">
            <thead>
              <tr>
                <th>Sr.no</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Designation</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->contact); ?></td>
                <td>
                  <?php if($user->designation == '0'): ?>
                  Super Admin
                  <?php else: ?>
                  Admin
                  <?php endif; ?>
                </td>
                <td>
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issuperadmin')): ?>
                  <a href="<?php echo e(route('admins.edit', $user->id)); ?>" class="btn" title="Edit User"><i class="material-icons">edit</i></a>
                  <button class="deletebutton btn red darken-1 modal-trigger" data-target="confirmationmodal" data-deleteid="<?php echo e($user->id); ?>" title="Delete User"><i class="material-icons">delete</i></button>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="6" class="center flow-text" id="emptymsg">No Users Found</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
          <div class="modal" id="confirmationmodal">
            <div class="modal-content center">
              <i class="large material-icons white red-text circle">error</i>
              <p class="flow-text">Are you sure you want to delete the user? This action cannot be undone</p>
            </div>
            <div class="modal-footer">
              <button class="btn modal-close waves-effect waves-light">Cancel</button>
              <form style="display: inline" action="<?php echo e(route('admins.destroy', 'ok')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <input type="hidden" id="deleteid" name="deleteid" value="">
                <button class="red btn waves-effect waves-light">Delete</button>
                &nbsp;
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/admins/manage-users.blade.php ENDPATH**/ ?>