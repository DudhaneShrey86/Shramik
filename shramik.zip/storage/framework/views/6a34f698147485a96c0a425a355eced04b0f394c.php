<?php $__env->startSection('title', 'My Tasks'); ?>
<?php $__env->startSection('csslinks'); ?>
<link rel="stylesheet" href="/css/consumers-show.css">
<link rel="stylesheet" href="/css/task-show.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" id="parentcontainer" data-id="task-show">
  <?php if(session()->has('custommsg')): ?>
  <p class="<?php echo e(session()->get('classes')); ?> card custommsgs"><span><?php echo e(session()->get('custommsg')); ?></span><i class="material-icons small"><?php echo e(session()->get('icon')); ?></i></p>
  <?php endif; ?>
  <div class="row">
    <div class="col s12">
      <div class="card">
        <ul class="tabs">
          <li class="tab col s3"><a href="#active">Active Tasks</a></li>
          <li class="tab col s3"><a href="#finished">Finished Tasks</a></li>
          <li class="tab col s3"><a href="#cancelled">Cancelled Tasks</a></li>
        </ul>
        <div class="divider nomargin">

        </div>
        <div class="card-content">
          <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
          $provider = $task->provider()->first();
          $consumer = $task->consumer()->first();
          $date = $task->created_at;
          $date = date_create($date);
          $date = date_format($date, "Y-m-d H:i:s A");
          ?>
          <div class="customrow" data-status="<?php echo e($task->status); ?>">
            <div class="customcard">
              <h6><a href="<?php echo e(route('providers.task.show', $task->id)); ?>" class="underlined"><?php echo e($task->title); ?></a></h6>
              <p class="blue-grey-text"> <span><?php echo e($consumer->name); ?></span> </p>
              <?php if($task->status == 2): ?>
              <div class="blue-grey-text margintop">
                <p>Review:</p>
                <p class="small-text"><?php echo e($task->review()->first()->text); ?></p>
              </div>
              <?php else: ?>

              <?php endif; ?>
              <p class="marginbottom"><small class="right">Created On: <?php echo e($date); ?></small> </p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

          <?php endif; ?>
          <div class="" id="active">

          </div>
          <div class="" id="finished">

          </div>
          <div class="" id="cancelled">

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/confirmmodals.js" charset="utf-8"></script>
<script src="/js/showtasks.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.providers-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_projects\shramik\resources\views/providers/task/showall.blade.php ENDPATH**/ ?>