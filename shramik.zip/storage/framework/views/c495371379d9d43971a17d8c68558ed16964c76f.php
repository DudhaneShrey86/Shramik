<?php echo e($slot); ?>

<?php /**PATH D:\laravel_projects\shramik\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>